import json
import random
import requests

def random_num():
    return(random.randint(1, 6))

def get_session_attributes(intent_request):
    sessionState = intent_request['sessionState']
    if 'sessionAttributes' in sessionState:
        return sessionState['sessionAttributes']
    
def close(intent_request, session_attributes, fulfillment_state, message):
    intent_request['sessionState']['intent']['state'] = fulfillment_state
    return {
        'sessionState': {
            'sessionAttributes': session_attributes,
            'dialogAction': {
                'type': 'Close'
            },
            'intent': intent_request['sessionState']['intent']
        },
        'messages': [message],
        'sessionId': intent_request['sessionId'],
        'requestAttributes': intent_request['requestAttributes'] if 'requestAttributes' in intent_request else None
    }

def getMovie(intent_request):
    session_attributes = get_session_attributes(intent_request)
    
    baseUrl = "http://image.tmdb.org/t/p/"
    movieURL = "https://api.themoviedb.org/3/discover/movie?include_adult=true&include_video=false&language=en-US&page=1&sort_by=popularity.desc&with_genres=27"
    headers = {
    "accept": "application/json",
    "Authorization": "Bearer eyJhbGciOiJIUzI1NiJ9.eyJhdWQiOiJhMTE2NDUzYmNmYjNiNjk2ODQ1MTNkODk2NDM5ZjgyMyIsInN1YiI6IjY0OWY5YWUwODFkYTM5MDE0ZDQ5NDJlNSIsInNjb3BlcyI6WyJhcGlfcmVhZCJdLCJ2ZXJzaW9uIjoxfQ.dOU5FdfZ_2INIPH3Wioh6fsOH3j9tuSqCv_HTL95Lng"
    }
    
    movieList = requests.get(movieURL, headers=headers)
    data = movieList.json()
    title = data["results"][random_num()]["title"]
    descr = data["results"][random_num()]["overview"]
    
    imageSize = "w300"
    imagePath = data["results"][random_num()]["backdrop_path"]

    message = {
        'contentType': 'ImageResponseCard',
        'content': "{} \n {}".format(title,descr),
        "imageResponseCard": {
                "title": "string",
                "subtitle": "string",
                "imageUrl": "{baseURL}{imageSize}{imagePath}".format(baseUrl,imageSize,imagePath)
        }      
    }
    fulfillment_state = "Fulfilled"
    return close(intent_request, session_attributes, fulfillment_state, message)


def dispatch(intent_request):
    intent_name = intent_request['sessionState']['intent']['name']
    response = None
    # Dispatch to your bot's intent handlers
    if intent_name == 'GetMovie':
        return getMovie(intent_request)

def lambda_handler(event, context):
    response = dispatch(event)
    return response